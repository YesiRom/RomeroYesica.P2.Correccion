
package model;

public class Criatura implements CSVSerializable, Comparable<Criatura> {

    private int id;
    private String nombre;
    private String investigador;
    private TipoCriatura clasificacion;

    public Criatura(int id, String nombre, String investigador, TipoCriatura clasificacion) {
        this.id = id;
        this.nombre = nombre;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() { return id; }
    public String getTitulo() { return nombre; }
    public String getInvestigador() { return investigador; }
    public TipoCriatura getClasificacion() { return clasificacion; }

    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toString() {
        return String.format(
            "Caso{id=%d, titulo='%s', investigador='%s', clasificacion=%s}",
             id, nombre, investigador, clasificacion
        );
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + investigador + "," + clasificacion;
    }

    /*
    public static Criatura fromCSV(String linea) {
        String[] p = linea.split(",");
        int id = Integer.parseInt(p[0].trim());
        String titulo = p[1].trim();
        String investigador = p[2].trim();
        TipoCriatura c = TipoCriatura.valueOf(p[3].trim());
        return new Criatura(id, titulo, investigador, c);
    }*/
    
      public static Criatura fromCSV(String criaturaCSV){
        criaturaCSV = criaturaCSV.substring(0, criaturaCSV.length());
        String[] datos = criaturaCSV.split(",");
        return new Criatura(Integer.parseInt(datos[0]), datos[1], datos[2], TipoCriatura.valueOf(datos[3]));
    }

    
      public TipoCriatura getTipo() {
        return clasificacion;
    }

    public String getNombre() {
        return nombre;
    }
      
     
    
}
