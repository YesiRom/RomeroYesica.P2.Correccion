package servicios;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;
import model.CSVSerializable;

public class BestiarioUpsideDown<T extends CSVSerializable & Comparable<T>> {

    private List<T> lista = new ArrayList<>();
    
      private void validarNoNulo(T ingreso) {
        if (ingreso == null) {
            throw new NullPointerException("ingreso nulo");
        }
    }

    public void agregar(T elem) { 
        validarNoNulo(elem);
        lista.add(elem);
    }
    
    
     private void validarIndice(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
     
    public T obtener(int i) {
        validarIndice(i);
        return lista.get(i);
    }
    
    public void eliminar(int i) {
        validarIndice(i);
        lista.remove(i);
    }

    public List<T> filtrar(Predicate<T> p) {
        List<T> listaFiltrada = new ArrayList<>();
        for (T e : lista) {
            if (p.test(e)) {
                listaFiltrada.add(e);
            }
        }
        return listaFiltrada;
    }

    public void ordenar() { 
          lista.sort((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void ordenar(Comparator<T> criterio) {
        lista.sort(criterio); 
    }

    public void paraCadaElemento(Consumer<T> accion) { 
         for (T p : lista) {
            accion.accept(p);
        }
    }
    
      
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(lista);
        }catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream deserealizador = new ObjectInputStream(new FileInputStream(ruta))) {
              lista = (List<T>) deserealizador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

   
    public void guardarEnCSV(String ruta) throws IOException {
     try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for (T item : lista) {
                escritor.write(item.toCSV());
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> transformacion) throws IOException {
         lista.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                lista.add(transformacion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
